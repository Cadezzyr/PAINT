wget --content-disposition https://zenodo.org/record/2235448/files/blur.tar?download=1
wget --content-disposition https://zenodo.org/record/2235448/files/digital.tar?download=1
wget --content-disposition https://zenodo.org/record/2235448/files/extra.tar?download=1
wget --content-disposition https://zenodo.org/record/2235448/files/noise.tar?download=1
wget --content-disposition https://zenodo.org/record/2235448/files/weather.tar?download=1

tar -zxvf blur.tar
tar -zxvf digital.tar
tar -zxvf extra.tar
tar -zxvf noise.tar
tar -zxvf weather.tar
